#ifndef FUNCTIONS_H_
#define FUNCTIONS_H_

#include <iostream>
#include <sstream>
#include <vector>

std::vector<std::string> split(std::string line);

#endif